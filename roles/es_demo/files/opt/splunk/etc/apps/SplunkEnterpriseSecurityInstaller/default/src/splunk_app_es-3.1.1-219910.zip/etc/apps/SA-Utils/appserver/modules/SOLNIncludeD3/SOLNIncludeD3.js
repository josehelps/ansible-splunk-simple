Splunk.Module.SOLNIncludeD3 = $.klass(Splunk.Module, {
    initialize: function($super, container) {
        $super(container);
        console.log("[SOLNIncludeD3] loaded d3");
        this.hide('HIDDEN MODULE KEY');
    }
});

