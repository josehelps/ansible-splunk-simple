/* Copyright (C) 2005-2010 IP2Location.com
 * All Rights Reserved
 *
 * This library is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; If not, see <http://www.gnu.org/licenses/>.
 */

#include "Python.h"
#include <stdio.h>
#include "IP2Location.h"

staticforward PyTypeObject IP2LocRecordType, IP2LocObjType;

typedef struct {
  PyObject_HEAD
  IP2Location* obj;
} IP2LocObj;

typedef struct {
  PyObject_HEAD
  IP2LocationRecord* rec;
} IP2LocRecord;


/* -------------------------------
	class building methods
	-------------------------------- */
static void IP2LocObj_dealloc(IP2LocObj* self)
{
		IP2Location_close(self->obj);
    PyObject_Del((PyObject*)self);
}

static void IP2LocRecord_dealloc(IP2LocRecord* self)
{
		IP2Location_free_record(self->rec);
    PyObject_Del((PyObject*)self);
}

static PyObject* IP2LocObj_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    IP2LocObj *self;
    self = PyObject_New(IP2LocObj, &IP2LocObjType);
    //self = (IP2LocObj *)type->tp_alloc(type, 0); // not supported in 2.0
    Py_XINCREF(self);
    self->obj = NULL;
    return (PyObject *)self;
}

static PyObject* IP2LocRecord_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    IP2LocRecord *self;
    self = PyObject_New(IP2LocRecord, &IP2LocRecordType);
    //self = (IP2LocRecord *)type->tp_alloc(type, 0); // not supported in 2.0
    return (PyObject *)self;
}

static int IP2LocObj_init(IP2LocObj *self, PyObject *args, PyObject *kwds)
{
    return 0;
}

static int IP2LocRecord_init(IP2LocRecord *self, PyObject *args, PyObject *kwds)
{

    return 0;
}

static PyObject* IP2LocObj_open (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* dbFile = NULL;
	int ok = 0;

	ok = PyArg_ParseTuple(args, "s", &dbFile);
	self->obj = IP2Location_open(dbFile);
	return (PyObject*) self;
}

static PyObject* IP2LocObj_get_country_short (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_country_short(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_country_long (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_country_long(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_region (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_region(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_city (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_city(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_isp (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_isp(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_latitude (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_latitude(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_longitude (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_longitude(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_domain (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_domain(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_zipcode (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_zipcode(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_timezone (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_timezone(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_netspeed (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_netspeed(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_idd_code (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_iddcode(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_area_code (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_areacode(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_weather_code (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_weatherstationcode(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_weather_name (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_weatherstationname(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_mcc (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_mcc(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_mnc (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_mnc(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_mobile_brand (IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_mobilebrand(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}

static PyObject* IP2LocObj_get_all(IP2LocObj *self, PyObject *args, PyObject *kwds) {
	char* ipaddr = NULL;
	int ok = 0;
	IP2LocationRecord* rec;
	IP2LocRecord* newRec;

	if(self->obj == NULL) {
		PyErr_SetString(PyExc_ReferenceError, "DB file is not opened!");
		return NULL;
	}

	ok = PyArg_ParseTuple(args, "s", &ipaddr);
	rec = IP2Location_get_all(self->obj, ipaddr);
	newRec = PyObject_New(IP2LocRecord, &IP2LocRecordType);
	newRec->rec = rec;
	return (PyObject*) newRec;
}


static PyMethodDef IP2LocObj_methods[] = {
		{"open", (PyCFunction)IP2LocObj_open, METH_VARARGS, "testing new module"},
		{"get_country_short", (PyCFunction)IP2LocObj_get_country_short, METH_VARARGS, "get country short"},
		{"get_country_long", (PyCFunction)IP2LocObj_get_country_long, METH_VARARGS, "get country long"},
		{"get_region", (PyCFunction)IP2LocObj_get_region, METH_VARARGS, "get region"},
		{"get_city", (PyCFunction)IP2LocObj_get_city, METH_VARARGS, "get city"},
		{"get_isp", (PyCFunction)IP2LocObj_get_isp, METH_VARARGS, "get isp"},
		{"get_latitude", (PyCFunction)IP2LocObj_get_latitude, METH_VARARGS, "get latitude"},
		{"get_longitude", (PyCFunction)IP2LocObj_get_longitude, METH_VARARGS, "get longitude"},
		{"get_domain", (PyCFunction)IP2LocObj_get_domain, METH_VARARGS, "get domain"},
		{"get_zipcode", (PyCFunction)IP2LocObj_get_zipcode, METH_VARARGS, "get zipcode"},
		{"get_timezone", (PyCFunction)IP2LocObj_get_timezone, METH_VARARGS, "get timezone"},
		{"get_netspeed", (PyCFunction)IP2LocObj_get_netspeed, METH_VARARGS, "get netspeed"},
		{"get_idd_code", (PyCFunction)IP2LocObj_get_idd_code, METH_VARARGS, "get idd code"},
		{"get_area_code", (PyCFunction)IP2LocObj_get_area_code, METH_VARARGS, "get area code"},
		{"get_weather_code", (PyCFunction)IP2LocObj_get_weather_code, METH_VARARGS, "get weather code"},
		{"get_weather_name", (PyCFunction)IP2LocObj_get_weather_name, METH_VARARGS, "get weather name"},
		{"get_mcc", (PyCFunction)IP2LocObj_get_mcc, METH_VARARGS, "get mcc"},
		{"get_mnc", (PyCFunction)IP2LocObj_get_mnc, METH_VARARGS, "get mnc"},
		{"get_mobile_brand", (PyCFunction)IP2LocObj_get_mobile_brand, METH_VARARGS, "get mobile brand"},
		{"get_all", (PyCFunction)IP2LocObj_get_all, METH_VARARGS, "get all"},
		//{"close", IP2LocObj_close, METH_VARARGS, "testing new module"},
		{NULL, NULL, 0, NULL}
};

static PyObject* IP2LocRecord_country_short(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->country_short);
}
static PyObject* IP2LocRecord_country_long(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->country_long);
}
static PyObject* IP2LocRecord_region(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->region);
}
static PyObject* IP2LocRecord_city(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->city);
}
static PyObject* IP2LocRecord_isp(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->isp);
}
static PyObject* IP2LocRecord_latitude(IP2LocRecord* self) {
		return Py_BuildValue("f", self->rec->latitude);
}
static PyObject* IP2LocRecord_longitude(IP2LocRecord* self) {
		return Py_BuildValue("f", self->rec->longitude);
}
static PyObject* IP2LocRecord_domain(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->domain);
}
static PyObject* IP2LocRecord_zipcode(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->zipcode);
}
static PyObject* IP2LocRecord_timezone(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->timezone);
}
static PyObject* IP2LocRecord_netspeed(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->netspeed);
}
static PyObject* IP2LocRecord_idd_code(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->iddcode);
}
static PyObject* IP2LocRecord_area_code(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->areacode);
}
static PyObject* IP2LocRecord_weather_code(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->weatherstationcode);
}
static PyObject* IP2LocRecord_weather_name(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->weatherstationname);
}
static PyObject* IP2LocRecord_mcc(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->mcc);
}
static PyObject* IP2LocRecord_mnc(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->mnc);
}
static PyObject* IP2LocRecord_mobile_brand(IP2LocRecord* self) {
		return Py_BuildValue("s", self->rec->mobilebrand);
}

static PyGetSetDef IP2LocRecord_getsets[] = {
		{"country_short", (getter)IP2LocRecord_country_short,	 0, "country_short",  NULL},
		{"country_long", 	(getter)IP2LocRecord_country_long, 	 0, "country_long", 	 NULL},
		{"region", 				(getter)IP2LocRecord_region,	 			 0, "region", 				 NULL},
		{"city",					(getter)IP2LocRecord_city,				   0, "city",					 NULL},
		{"isp",					  (getter)IP2LocRecord_isp,						 0, "isp",					   NULL},
		{"latitude",			(getter)IP2LocRecord_latitude,		   0, "latitude",			 NULL},
		{"longitude",			(getter)IP2LocRecord_longitude,			 0, "longitude",			 NULL},
		{"domain",				(getter)IP2LocRecord_domain,			   0, "domain",				 NULL},
		{"zipcode",				(getter)IP2LocRecord_zipcode,				 0, "zipcode",				 NULL},
		{"timezone",			(getter)IP2LocRecord_timezone,		   0, "timezone",			 NULL},
		{"netspeed",			(getter)IP2LocRecord_netspeed,		   0, "netspeed",			 NULL},
		{"idd_code",			(getter)IP2LocRecord_idd_code,		   0, "idd_code",			 NULL},
		{"area_code",			(getter)IP2LocRecord_area_code,		   0, "area_code",			 NULL},
		{"weather_code",			(getter)IP2LocRecord_weather_code,		   0, "weather_code",			 NULL},
		{"weather_name",			(getter)IP2LocRecord_weather_name,		   0, "weather_name",			 NULL},
		{"mcc",			(getter)IP2LocRecord_mcc,		   0, "mcc",			 NULL},
		{"mnc",			(getter)IP2LocRecord_mnc,		   0, "mnc",			 NULL},
		{"mobile_brand",			(getter)IP2LocRecord_mobile_brand,		   0, "mobile_brand",			 NULL},
		{NULL}
};



static PyMethodDef IP2Location_methods[] = {
		//{"no function", (PyCFunction)no_func, METH_VARARGS, "placeholder"},
		{NULL, NULL, 0, NULL}
};

static PyTypeObject IP2LocObjType = {
    PyObject_HEAD_INIT(NULL)
    0,                         	/*ob_size*/
    "ip2location.IP2Location", 	/*tp_name*/
    sizeof(IP2LocObj), 					/*tp_basicsize*/
    0,                         	/*tp_itemsize*/
    (destructor)IP2LocObj_dealloc,	/*tp_dealloc*/
    0,                         	/*tp_print*/
    0,                         	/*tp_getattr*/
    0,                         	/*tp_setattr*/
    0,                         	/*tp_compare*/
    0,                         	/*tp_repr*/
    0,                         	/*tp_as_number*/
    0,                         	/*tp_as_sequence*/
    0,                         	/*tp_as_mapping*/
    0,                         	/*tp_hash */
    0,                         	/*tp_call*/
    0,                         	/*tp_str*/
    0,                         	/*tp_getattro*/
    0,                         	/*tp_setattro*/
    0,                         	/*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT,        	/*tp_flags*/
    "IP2Location objects", 	  	/* tp_doc */
    0,		               				/* tp_traverse */
    0,		               				/* tp_clear */
    0,		               				/* tp_richcompare */
    0,		               				/* tp_weaklistoffset */
    0,		               				/* tp_iter */
    0,		               				/* tp_iternext */
    IP2LocObj_methods,    			/* tp_methods */
    0,								    			/* tp_members */
    0,                   				/* tp_getset */
    0,                   				/* tp_base */
    0,                   				/* tp_dict */
    0,                   				/* tp_descr_get */
    0,                   				/* tp_descr_set */
    0,                   				/* tp_dictoffset */
    (initproc)IP2LocObj_init,		/* tp_init */
    0,                   				/* tp_alloc */
    IP2LocObj_new,           		/* tp_new */
};

static PyTypeObject IP2LocRecordType = {
    PyObject_HEAD_INIT(NULL)
    0,                         	/*ob_size*/
    "ip2location.IP2LocationRecord", 	/*tp_name*/
    sizeof(IP2LocRecord), 			/*tp_basicsize*/
    0,                         	/*tp_itemsize*/
    (destructor)IP2LocRecord_dealloc, 	/*tp_dealloc*/
    0,                         	/*tp_print*/
    0,                         	/*tp_getattr*/
    0,                         	/*tp_setattr*/
    0,                         	/*tp_compare*/
    0,                         	/*tp_repr*/
    0,                         	/*tp_as_number*/
    0,                         	/*tp_as_sequence*/
    0,                         	/*tp_as_mapping*/
    0,                         	/*tp_hash */
    0,                         	/*tp_call*/
    0,                         	/*tp_str*/
    0,                         	/*tp_getattro*/
    0,                         	/*tp_setattro*/
    0,                         	/*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT,        	/*tp_flags*/
    "IP2Location record", 	  	/* tp_doc */
    0,		               				/* tp_traverse */
    0,		               				/* tp_clear */
    0,		               				/* tp_richcompare */
    0,		               				/* tp_weaklistoffset */
    0,		               				/* tp_iter */
    0,		               				/* tp_iternext */
    0,										      /* tp_methods */
    0,										      /* tp_members */
    IP2LocRecord_getsets,				/* tp_getset */
    0,                   				/* tp_base */
    0,                   				/* tp_dict */
    0,                   				/* tp_descr_get */
    0,                   				/* tp_descr_set */
    0,                   				/* tp_dictoffset */
    (initproc)IP2LocRecord_init,/* tp_init */
    0,                   				/* tp_alloc */
    IP2LocRecord_new,           /* tp_new */
};

#ifndef PyMODINIT_FUNC	/* declarations for DLL import/export */
#define PyMODINIT_FUNC void
#endif
PyMODINIT_FUNC initIP2Location(void) {
	PyObject* m;

  if (PyType_Ready(&IP2LocObjType) < 0)
  	return;
  Py_INCREF(&IP2LocObjType);

	 if (PyType_Ready(&IP2LocRecordType) < 0)
  	return;
  Py_INCREF(&IP2LocRecordType);

	m = Py_InitModule3("IP2Location", IP2Location_methods, "IP2Location Module");
	PyModule_AddObject(m, "IP2Location", (PyObject *)&IP2LocObjType);

}
