# Copyright (C) 2005-2010 IP2Location.com
# All Rights Reserved
#
# This library is free software: you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation, either
# version 3 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; If not, see <http://www.gnu.org/licenses/>.

from distutils.core import setup, Extension

module1 = Extension('IP2Location',
                   	sources = ['IP2Location.c'],
                   	libraries = ['IP2Location'],
										library_dirs = ['../C-IP2Location-4.0.2/libIP2Location/.libs'],
										include_dirs = ['../C-IP2Location-4.0.2/libIP2Location', '../C-IP2Location-4.0.2/libIP2Location/iMath'])

setup (name = 'Python-IP2Location',
       version = '4.0.0',
       description = 'Python wrapper for IP2Location C API',
       ext_modules = [module1])
